package Controladora;

import Dominio.Habitacion;
import Dominio.Hotel;
import Dominio.Reserva;
import Persistencia.PHabitacion;
import Persistencia.PHotel;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.Set;
import java.util.HashSet;


public class ControladoraHabitacion {
    private static Scanner escaner = new Scanner(System.in);
    private List<Habitacion> habitaciones;
    private List<Reserva> reservas;

    public ControladoraHabitacion() {
        this.habitaciones = PHabitacion.listarHabitaciones(); // Cargar las habitaciones desde la persistencia
        this.reservas = new ArrayList<>(); // Deberías cargar las reservas desde una fuente de datos si es necesario
    }

    public void agregarHabitacion() {
        System.out.println("Agregar habitación");

        int idHabitacion;
        do {
            System.out.print("Ingrese ID de la habitación: ");
            try {
                idHabitacion = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idHabitacion = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idHabitacion == 0);

        System.out.print("Ingrese ID del hotel: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        // Obtener el objeto Hotel
        Hotel hotel = PHotel.conseguirHotel(idHotel);

        // Verificar si el hotel fue encontrado
        if (hotel == null) {
            System.out.println("Hotel no encontrado. No se puede agregar la habitación.");
            return;
        }

        System.out.print("Ingrese la capacidad de camas: ");
        int capacidadCamas = Integer.parseInt(escaner.nextLine());

        System.out.print("¿Tiene cama matrimonial? (true/false): ");
        boolean camaMatrimonial = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene aire acondicionado? (true/false): ");
        boolean aireAcondicionado = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene balcón? (true/false): ");
        boolean balcon = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene vista? (true/false): ");
        boolean vista = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Incluye amenities? (true/false): ");
        boolean amenities = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Está ocupada? (true/false): ");
        boolean ocupada = Boolean.parseBoolean(escaner.nextLine());

        Habitacion habitacion = new Habitacion(idHabitacion, capacidadCamas, camaMatrimonial,
                aireAcondicionado, balcon, vista, amenities, ocupada, hotel);

        if (PHabitacion.agregarHabitacion(habitacion)) {
            habitaciones.add(habitacion); // Agregar la habitación a la lista local
            System.out.println("Habitación agregada con éxito.");
        } else {
            System.out.println("Hubo un error al agregar la habitación.");
        }
    }

    public void eliminarHabitacion() {
        System.out.print("Ingrese ID de la habitación a eliminar: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        if (PHabitacion.eliminarHabitacion(idHabitacion)) {
            habitaciones.removeIf(h -> h.getIdHabitacion() == idHabitacion); // Eliminar de la lista local
            System.out.println("Habitación eliminada con éxito.");
        } else {
            System.out.println("No se pudo eliminar la habitación.");
        }
    }

    public void modificarHabitacion() {
        System.out.print("Ingrese ID de la habitación a modificar: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);
        if (habitacion == null) {
            System.out.println("Habitación no encontrada.");
            return;
        }

        System.out.print("Ingrese la capacidad de camas (" + habitacion.getCapacidadCamas() + "): ");
        String capacidadCamas = escaner.nextLine();
        if (!capacidadCamas.isEmpty())
            habitacion.setCapacidadCamas(Integer.parseInt(capacidadCamas));

        System.out.print("¿Tiene cama matrimonial? (" + habitacion.isCamaMatrimonial() + "): ");
        String camaMatrimonial = escaner.nextLine();
        if (!camaMatrimonial.isEmpty())
            habitacion.setCamaMatrimonial(Boolean.parseBoolean(camaMatrimonial));

        System.out.print("¿Tiene aire acondicionado? (" + habitacion.isAireAcondicionado() + "): ");
        String aireAcondicionado = escaner.nextLine();
        if (!aireAcondicionado.isEmpty())
            habitacion.setAireAcondicionado(Boolean.parseBoolean(aireAcondicionado));

        System.out.print("¿Tiene balcón? (" + habitacion.isBalcon() + "): ");
        String balcon = escaner.nextLine();
        if (!balcon.isEmpty())
            habitacion.setBalcon(Boolean.parseBoolean(balcon));

        System.out.print("¿Tiene vista? (" + habitacion.isVista() + "): ");
        String vista = escaner.nextLine();
        if (!vista.isEmpty())
            habitacion.setVista(Boolean.parseBoolean(vista));

        System.out.print("¿Incluye amenities? (" + habitacion.isAmenities() + "): ");
        String amenities = escaner.nextLine();
        if (!amenities.isEmpty())
            habitacion.setAmenities(Boolean.parseBoolean(amenities));

        System.out.print("¿Está ocupada? (" + habitacion.isOcupada() + "): ");
        String ocupada = escaner.nextLine();
        if (!ocupada.isEmpty())
            habitacion.setOcupada(Boolean.parseBoolean(ocupada));

        if (PHabitacion.modificarHabitacion(habitacion)) {
            System.out.println("Habitación modificada con éxito.");
        } else {
            System.out.println("Hubo un error al modificar la habitación.");
        }
    }

    public void conseguirHabitacion() {
        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);
        if (habitacion != null) {
            System.out.println(habitacion);
        } else {
            System.out.println("Habitación no encontrada.");
        }
    }

    public void listarHabitaciones() {
        System.out.println("Listado de habitaciones:");
        for (Habitacion habitacion : habitaciones) {
            System.out.println(habitacion);
        }
    }

    public void obtenerHabitacionesConReserva() {
        // Llamamos al método de PHabitacion para obtener las habitaciones con reservas
        List<Habitacion> habitacionesConReserva = PHabitacion.listarHabitacionesConReserva();

        // Mostramos las habitaciones con reserva
        System.out.println("Habitaciones con reserva:");
        if (habitacionesConReserva.isEmpty()) {
            System.out.println("No hay habitaciones con reservas.");
        } else {
            for (Habitacion hab : habitacionesConReserva) {
                System.out.println(hab);
            }
        }
    }

    public void obtenerHabitacionesSinReserva() {
        // Llamamos al método de PHabitacion para obtener las habitaciones sin reservas
        List<Habitacion> habitacionesSinReserva = PHabitacion.listarHabitacionesSinReserva();

        // Mostramos las habitaciones sin reserva
        System.out.println("Habitaciones sin reserva:");
        if (habitacionesSinReserva.isEmpty()) {
            System.out.println("No hay habitaciones disponibles sin reservas.");
        } else {
            for (Habitacion hab : habitacionesSinReserva) {
                System.out.println(hab);
            }
        }
    }

}
