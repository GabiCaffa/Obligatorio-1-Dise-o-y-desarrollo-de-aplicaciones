import Controladora.*;

import java.util.Scanner;
import Controladora.ControladoraHotel;
import Controladora.ControladoraHuesped;
import Controladora.ControladoraHabitacion;
import Controladora.ControladoraReserva;
import Controladora.ControladoraTarifa;


public class Main {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            ControladoraHotel controladoraHotel = new ControladoraHotel();
            ControladoraHuesped controladoraHuesped = new ControladoraHuesped();
            ControladoraHabitacion controladoraHabitacion = new ControladoraHabitacion();
            ControladoraReserva controladoraReserva = new ControladoraReserva();
            ControladoraTarifa controladoraTarifa = new ControladoraTarifa();
            int opcion = -1; // Inicializar opcion con un valor no válido
        do {
            System.out.println("----- Menú Principal -----");
            System.out.println("1. Gestión de Hoteles");
            System.out.println("2. Gestión de Huéspedes");
            System.out.println("3. Gestión de Habitaciones");
            System.out.println("4. Gestión de Reservas");
            System.out.println("5. Gestión de Tarifas"); // Nueva opción para tarifas
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1:
                        gestionarHoteles(scanner, controladoraHotel);
                        break;
                    case 2:
                        gestionarHuespedes(scanner, controladoraHuesped);
                        break;
                    case 3:
                        gestionarHabitaciones(scanner, controladoraHabitacion);
                        break;
                    case 4:
                        gestionarReservas(scanner, controladoraReserva);
                        break;
                    case 5:
                        gestionarTarifas(scanner, controladoraTarifa); // Llamado al método de tarifas
                        break;
                    case 0:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción inválida. Intente nuevamente.");
                }

                System.out.println();
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void gestionarHoteles(Scanner scanner, ControladoraHotel controladoraHotel) {
        int opcion;
        do {
            System.out.println("----- Gestión de Hoteles -----");
            System.out.println("1. Agregar hotel");
            System.out.println("2. Eliminar hotel");
            System.out.println("3. Modificar hotel");
            System.out.println("4. Conseguir hotel");
            System.out.println("5. Listar hoteles");
            System.out.println("6. Consultar hoteles por ciudad");
            System.out.println("7. Consultar hoteles por nombre");
            System.out.println("8. Consultar hoteles por estrellas");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1:
                        controladoraHotel.agregarHotel();
                        break;
                    case 2:
                        controladoraHotel.eliminarHotel();
                        break;
                    case 3:
                        controladoraHotel.modificarHotel();
                        break;
                    case 4:
                        controladoraHotel.conseguirHotel();
                        break;
                    case 5:
                        controladoraHotel.listarHoteles();
                        break;
                    case 6:
                        controladoraHotel.consultarHotelesPorCiudad();
                        break;
                    case 7:
                        controladoraHotel.consultarHotelesPorNombre();
                        break;
                    case 8:
                        controladoraHotel.consultarHotelesPorEstrellas();
                        break;
                    case 0:
                        System.out.println("Regresando al menú principal...");
                        break;
                    default:
                        System.out.println("Opción inválida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                opcion = -1;
            }
        } while (opcion != 0);
    }

    private static void gestionarHuespedes(Scanner scanner, ControladoraHuesped controladoraHuesped) {
        int opcion;
        do {
            System.out.println("----- Gestión de Huéspedes -----");
            System.out.println("1. Agregar huésped");
            System.out.println("2. Eliminar huésped");
            System.out.println("3. Modificar huésped");
            System.out.println("4. Conseguir huésped");
            System.out.println("5. Listar huéspedes");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    controladoraHuesped.agregarHuesped();
                    break;
                case 2:
                    controladoraHuesped.eliminarHuesped();
                    break;
                case 3:
                    controladoraHuesped.modificarHuesped();
                    break;
                case 4:
                    controladoraHuesped.conseguirHuesped();
                    break;
                case 5:
                    controladoraHuesped.listarHuespedes();
                    break;
                case 0:
                    System.out.println("Regresando al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }

    private static void gestionarHabitaciones(Scanner scanner, ControladoraHabitacion controladoraHabitacion) {
        int opcion;
        do {
            System.out.println("----- Gestión de Habitaciones -----");
            System.out.println("1. Agregar habitación");
            System.out.println("2. Eliminar habitación");
            System.out.println("3. Modificar habitación");
            System.out.println("4. Conseguir habitación");
            System.out.println("5. Listar habitaciones");
            System.out.println("6. Listar habitaciones con reserva");
            System.out.println("7. Listar habitaciones sin reserva");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    controladoraHabitacion.agregarHabitacion();
                    break;
                case 2:
                    controladoraHabitacion.eliminarHabitacion();
                    break;
                case 3:
                    controladoraHabitacion.modificarHabitacion();
                    break;
                case 4:
                    controladoraHabitacion.conseguirHabitacion();
                    break;
                case 5:
                    controladoraHabitacion.listarHabitaciones();
                    break;
                case 6:
                    controladoraHabitacion.obtenerHabitacionesConReserva();
                    break;
                case 7:
                    controladoraHabitacion.obtenerHabitacionesSinReserva();
                    break;
                case 0:
                    System.out.println("Regresando al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }


    private static void gestionarReservas(Scanner scanner, ControladoraReserva controladoraReserva) {
        int opcion;
        do {
            System.out.println("----- Gestión de Reservas -----");
            System.out.println("1. Crear reserva");
            System.out.println("2. Cancelar reserva");
            System.out.println("3. Modificar reserva");
            System.out.println("4. Consultar reserva");
            System.out.println("5. Listar reservas");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    controladoraReserva.agregarReserva();
                    break;
                case 2:
                    controladoraReserva.eliminarReserva();
                    break;
                case 3:
                    controladoraReserva.modificarReserva();
                    break;
                case 4:
                    controladoraReserva.conseguirReserva();
                    break;
                case 5:
                    controladoraReserva.listarReservas();
                    break;
                case 0:
                    System.out.println("Regresando al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }

    private static void gestionarTarifas(Scanner scanner, ControladoraTarifa controladoraTarifa) {
        int opcion;
        do {
            System.out.println("----- Menú de Gestión de Tarifas -----");
            System.out.println("1. Agregar tarifa");
            System.out.println("2. Eliminar tarifa");
            System.out.println("3. Modificar tarifa");
            System.out.println("4. Conseguir tarifa");
            System.out.println("5. Listar tarifas");
            System.out.println("0. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");

            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    controladoraTarifa.agregarTarifa();
                    break;
                case 2:
                    controladoraTarifa.eliminarTarifa();
                    break;
                case 3:
                    controladoraTarifa.modificarTarifa();
                    break;
                case 4:
                    controladoraTarifa.conseguirTarifa();
                    break;
                case 5:
                    controladoraTarifa.listarTarifas();
                    break;
                case 0:
                    System.out.println("Regresando al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }
}
