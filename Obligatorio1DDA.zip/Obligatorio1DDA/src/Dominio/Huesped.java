package Dominio;

public class Huesped {
    private int idHuesped;
    private String nombre;
    private String aPaterno;
    private String aMaterno;
    private String tipoDocumento;
    private String numDocumento;
    private String fechaNacimiento; // Se mantiene como String
    private String telefono;
    private String pais;

    public Huesped(int idHuesped, String nombre, String aPaterno, String aMaterno,
                   String tipoDocumento, String numDocumento, String fechaNacimiento,
                   String telefono, String pais) {
        this.idHuesped = idHuesped;
        this.nombre = nombre;
        this.aPaterno = aPaterno;
        this.aMaterno = aMaterno;
        this.tipoDocumento = tipoDocumento;
        this.numDocumento = numDocumento;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.pais = pais;
    }

    // Getters y Setters
    public int getIdHuesped() {
        return idHuesped;
    }

    public void setIdHuesped(int idHuesped) {
        this.idHuesped = idHuesped;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getaPaterno() {
        return aPaterno;
    }

    public void setaPaterno(String aPaterno) {
        this.aPaterno = aPaterno;
    }

    public String getaMaterno() {
        return aMaterno;
    }

    public void setaMaterno(String aMaterno) {
        this.aMaterno = aMaterno;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumDocumento() {
        return numDocumento;
    }

    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
    public String toString() {
        return "ID: " + idHuesped +
                ", Nombre: " + nombre + " " + aPaterno + " " + aMaterno +
                ", Tipo Documento: " + tipoDocumento +
                ", Número Documento: " + numDocumento +
                ", Fecha Nacimiento: " + fechaNacimiento +
                ", Teléfono: " + telefono +
                ", País: " + pais;
    }
}
